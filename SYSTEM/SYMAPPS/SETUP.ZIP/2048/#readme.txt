======================================= 
*     ___       ____  _    ___  ___   * 
*    /__  /__/ / / / /_\  /  / /__    * 
*   ___/ ___/ /   / /__/ /__/ ___/    * 
*       SYMBIOSIS MULTITASKING        * 
*       BASED OPERATING SYSTEM        * 
======================================= 
                2 0 4 8 
         (2048 sliding puzzle) 
--------------------------------------- 
  Author: Trebmint/SymbiosiS 
 Version: 1.0 
    Date: 20.10.2021 
Requires: SymbOS 3.0 
  Memory: 192K (or more) 
--------------------------------------- 
2048 is a sliding tile puzzle game. It 
is played on a plain 4x4 grid, with 
numbered tiles that slide when a 
player moves them using the four arrow 
keys. Every turn, a new tile randomly 
appears in an empty spot on the board 
with a value of either 2 or 4. Tiles 
slide as far as possible in the chosen 
direction until they are stopped by 
either another tile or the edge of the 
grid. If two tiles of the same number 
collide while moving, they will merge 
into a tile with the total value of 
the two tiles that collided. The goal 
is to add as much tiles as possible 
and reach a very high number. 
--------------------------------------- 
This archive contains the following 
files: 
....................................... 
2048.exe       Executable 
edge1.qs2      additional file(s) 
edge2.qs2     
logo.qs2      
ntiles.qs2    
sources\       Source codes 
2048-CPC.DSK 
               disk image (CPC or PCW) 
2048-FAT.DSK 
               disk image (MSX or EP) 
--------------------------------------- 
For additional information please visit 
         http://www.symbos.org 
======================================= 
