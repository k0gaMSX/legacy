======================================= 
*     ___       ____  _    ___  ___   * 
*    /__  /__/ / / / /_\  /  / /__    * 
*   ___/ ___/ /   / /__/ /__/ ___/    * 
*       SYMBIOSIS MULTITASKING        * 
*       BASED OPERATING SYSTEM        * 
======================================= 
             P A C - M A N 
       (classical Pac-Man clone) 
--------------------------------------- 
  Author: Prodatron/SymbiosiS 
 Version: 1.1 
    Date: 04.07.2007 
Requires: SymbOS 1.1 
  Memory: 128K (or more) 
--------------------------------------- 
Pac-Man for SymbOS is a complete clone 
of the original game from 1980. It 
uses 16 colour sprites, which will be 
downrendered automatically on 4 colour 
systems. The game supports keyboard 
and joystick control, multilevel and 
different speeds. 
--------------------------------------- 
This archive contains the following 
files: 
....................................... 
pacman.exe     Executable 
sources\       Source codes 
Pac-Man-CPC.DSK 
               disk image (CPC or PCW) 
Pac-Man-FAT.DSK 
               disk image (MSX or EP) 
--------------------------------------- 
For additional information please visit 
         http://www.symbos.org 
======================================= 
