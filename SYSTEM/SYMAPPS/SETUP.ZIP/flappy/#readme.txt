======================================= 
*     ___       ____  _    ___  ___   * 
*    /__  /__/ / / / /_\  /  / /__    * 
*   ___/ ___/ /   / /__/ /__/ ___/    * 
*       SYMBIOSIS MULTITASKING        * 
*       BASED OPERATING SYSTEM        * 
======================================= 
         F L A P P Y   B I R D 
         (Side scroller game) 
--------------------------------------- 
  Author: EdoZ/SymbiosiS 
 Version: 1.0 
    Date: 30.12.2021 
Requires: SymbOS 3.1 (G9K) 
  Memory: 192K (or more) 
--------------------------------------- 
Flappy Bird is a side-scroller where 
the player controls a bird, attempting 
to fly between columns of green pipes 
without hitting them. 
--------------------------------------- 
This archive contains the following 
files: 
....................................... 
flappy.exe     Executable 
flappy1.qpt    additional file(s) 
flappy2.qpt   
flappy3.qpt   
flappy4.qpt   
--------------------------------------- 
For additional information please visit 
         http://www.symbos.org 
======================================= 
