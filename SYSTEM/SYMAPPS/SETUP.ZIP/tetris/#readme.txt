======================================= 
*     ___       ____  _    ___  ___   * 
*    /__  /__/ / / / /_\  /  / /__    * 
*   ___/ ___/ /   / /__/ /__/ ___/    * 
*       SYMBIOSIS MULTITASKING        * 
*       BASED OPERATING SYSTEM        * 
======================================= 
              T E T R I S 
        (Classical tetris port) 
--------------------------------------- 
  Author: EdoZ/SymbiosiS 
 Version: 2.1 
    Date: 07.10.2016 
Requires: SymbOS 2.1 
  Memory: 192K (or more) 
--------------------------------------- 
This is a port of the classical Tetris 
game. This game was developed with 
Quigs. Tetris is the first game that 
have a scalable mode. This means it 
will choose the best 1:1 size in 
different resolutions, in a window or 
in fullscreen. 
--------------------------------------- 
This archive contains the following 
files: 
....................................... 
tetris.exe     Executable 
tetris.icn     additional file(s) 
tetris1.gsh   
tetris2.gsh   
tetris3.gsh   
Tetris-CPC.DSK 
               disk image (CPC or PCW) 
Tetris-FAT.DSK 
               disk image (MSX or EP) 
--------------------------------------- 
For additional information please visit 
         http://www.symbos.org 
======================================= 
