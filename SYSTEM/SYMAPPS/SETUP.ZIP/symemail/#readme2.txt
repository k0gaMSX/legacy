
┏━━━┓╋╋╋╋╋╋┏┓╋╋╋╋╋╋╋╋┏━━━┓╋┏━┓┏━┳━━━┳━━┳┓
┃┏━┓┃╋╋╋╋╋╋┃┃╋╋╋╋╋╋╋╋┃┏━━┛╋┃┃┗┛┃┃┏━┓┣┫┣┫┃
┃┗━━┳┓╋┏┳┓┏┫┗━┳━━┳━━┓┃┗━━┓╋┃┏┓┏┓┃┃╋┃┃┃┃┃┃
┗━━┓┃┃╋┃┃┗┛┃┏┓┃┏┓┃━━┫┃┏━┳┻━┫┃┃┃┃┃┗━┛┃┃┃┃┃╋┏┓
┃┗━┛┃┗━┛┃┃┃┃┗┛┃┗┛┣━━┃┃┗━┻┳━┫┃┃┃┃┃┏━┓┣┫┣┫┗━┛┃
┗━━━┻━┓┏┻┻┻┻━━┻━━┻━━┛┗━━━┛╋┗┛┗┛┗┻┛╋┗┻━━┻━━━┛
╋╋╋╋┏━┛┃SymbOS E-Mail version 0.5.20211230 
╋╋╋╋┗━━┛

By E. van Zanten (EdoZ) evanzanten@home.nl

Thank you for using SymbOS email. Please be aware that SymbOS email can harm your emails on your server.
This program is far from perfect but it proofs that you can send and receive mails on your 8 bit machine.
Using a multitasking operation system (SymbOS)

Read the about and help in the application for more information.

remarks for version 0.5.20211230

-Base64 implementation for attachments not complete for attachments (only for textbased applications)
-Attacments are stored on disk in base64 format
-I suggest you to use opensource Hmailserver for windows or linux as mailserver host
-Sometimes text is not wrapped correctly due to different MIME formats which are partly supported
-Use plain text for the best results for receving and sending emails. HTML is not supported. 
-Date and Time is used when the mail is received in SymbOS
-mails sent from SymbOS E-mail can sometime be detected as spam due to restrictions on mailservers
-When there is a need for encrypted connection you can use a tool suchs as stunnel
-Only basic POP3 and SMTP are supported (no IMAP4) support in this version
-SymbOS E-Mail needs a FAT16 or FAT32 mass storage device for the local mail store. 
-SymbOS E-Mail is sometimes hanging when opening the filedialogbox screen
-SymbOS E-Mail needs at least 64k free memory and SymbOS version 3.1 due to memory handling 

If you have a question or suggestion please contact me at evanzanten@home.nl