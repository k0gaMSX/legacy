======================================= 
*     ___       ____  _    ___  ___   * 
*    /__  /__/ / / / /_\  /  / /__    * 
*   ___/ ___/ /   / /__/ /__/ ___/    * 
*       SYMBIOSIS MULTITASKING        * 
*       BASED OPERATING SYSTEM        * 
======================================= 
       S Y M B O S   E - M A I L 
            (E-mail client) 
--------------------------------------- 
  Author: EdoZ/SymbiosiS 
 Version: 0.5 
    Date: 30.12.2021 
Requires: SymbOS 3.1 
  Memory: 192K (or more) 
--------------------------------------- 
SymbOS E-Mail is a full working email 
client for SymbOS. 
--------------------------------------- 
This archive contains the following 
files: 
....................................... 
symemail.exe   Executable 
#readme2.txt   additional file(s) 
base64.exe    
maildat0.qs1  
maildat0.qs2  
maildat1.qs1  
maildat1.qs2  
maildat2.qs1  
maildat2.qs2  
symemail.ban  
symemail.bin  
symemail.hlp  
SymbOSE-Mail-CPC.DSK 
               disk image (CPC or PCW) 
SymbOSE-Mail-FAT.DSK 
               disk image (MSX or EP) 
--------------------------------------- 
For additional information please visit 
         http://www.symbos.org 
======================================= 
