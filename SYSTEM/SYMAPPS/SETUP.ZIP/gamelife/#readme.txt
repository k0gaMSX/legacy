======================================= 
*     ___       ____  _    ___  ___   * 
*    /__  /__/ / / / /_\  /  / /__    * 
*   ___/ ___/ /   / /__/ /__/ ___/    * 
*       SYMBIOSIS MULTITASKING        * 
*       BASED OPERATING SYSTEM        * 
======================================= 
        G A M E   O F   L I F E 
         (Cellular automaton) 
--------------------------------------- 
  Author: Prodatron/SymbiosiS 
 Version: 1.1 
    Date: 02.06.2014 
Requires: SymbOS 2.0 
  Memory: 128K (or more) 
--------------------------------------- 
Conways Game of Life is a cellular 
automaton devised by the British 
mathematician John Horton Conway in 
1970. It is a zero-player game, 
meaning that its evolution is 
determined by its initial state, 
requiring no further input. One 
interacts with the Game of Life by 
creating an initial configuration and 
observing how it evolves. It is Turing 
complete and can simulate a universal 
constructor or any other Turing 
machine. In contrast to most other 
implementations this version for 
SymbOS provides a huge library of 
predefined objects and complete sets 
as well as the possibility to use 
other surviving rules and so emulate 
different "worlds". 
--------------------------------------- 
This archive contains the following 
files: 
....................................... 
gamelife.exe   Executable 
gamelife.dat   additional file(s) 
gamelife.hlp   Help 
sources\       Source codes 
GameOfLife-CPC.DSK 
               disk image (CPC or PCW) 
GameOfLife-FAT.DSK 
               disk image (MSX or EP) 
--------------------------------------- 
For additional information please visit 
         http://www.symbos.org 
======================================= 
