======================================= 
*     ___       ____  _    ___  ___   * 
*    /__  /__/ / / / /_\  /  / /__    * 
*   ___/ ___/ /   / /__/ /__/ ___/    * 
*       SYMBIOSIS MULTITASKING        * 
*       BASED OPERATING SYSTEM        * 
======================================= 
              S Y M R O M 
          (ROM file launcher) 
--------------------------------------- 
  Author: NYYRIKKI 
 Version: 1.0 
    Date: 30.06.2007 
Requires: SymbOS 1.1 (MSX) 
  Memory: 256K (or more) 
--------------------------------------- 
This application starts ROM-files from 
SymbOS. Sizes 8KB-48KB are supported. 
Some programs may require disk drive 
to be disabled in order to work. You 
can do that by holding SHIFT-key down 
while computer reboots. If you are 
using Sunrise IDE or CF interface, you 
can disable it by holding  "INS"-key 
down at boot. Novaxis SCSI can be 
disabled by holding "GRAPH"-key down 
at boot. 
--------------------------------------- 
This archive contains the following 
files: 
....................................... 
symrom.exe     Executable 
SymROM-FAT.DSK 
               disk image (MSX or EP) 
--------------------------------------- 
For additional information please visit 
         http://www.symbos.org 
======================================= 
