======================================= 
*     ___       ____  _    ___  ___   * 
*    /__  /__/ / / / /_\  /  / /__    * 
*   ___/ ___/ /   / /__/ /__/ ___/    * 
*       SYMBIOSIS MULTITASKING        * 
*       BASED OPERATING SYSTEM        * 
======================================= 
             S O K O B A N 
             (Puzzle Game) 
--------------------------------------- 
  Author: Prodatron/SymbiosiS 
 Version: 1.0 
    Date: 14.10.2021 
Requires: SymbOS 2.1 
  Memory: 128K (or more) 
--------------------------------------- 
Sokoban for SymbOS is a quite advanced 
implementation of the classic Sokoban 
game. This version extends the 
original game principle with a lot of 
additional puzzle objects such as 
coloured boxes, ice floors, holes, 
portals, rails and magnets. 
--------------------------------------- 
This archive contains the following 
files: 
....................................... 
sokoban.exe    Executable 
sok-clas.ysb   additional file(s) 
sok-colr.ysb  
sok-frag.ysb  
sok-ice.ysb   
sok-magn.ysb  
sok-mdrn.ysb  
sok-port.ysb  
sok-rail.ysb  
sok-room.ysb  
sokoban.hlp    Help 
sources\       Source codes 
Sokoban-CPC.DSK 
               disk image (CPC or PCW) 
Sokoban-FAT.DSK 
               disk image (MSX or EP) 
--------------------------------------- 
For additional information please visit 
         http://www.symbos.org 
======================================= 
