======================================= 
*     ___       ____  _    ___  ___   * 
*    /__  /__/ / / / /_\  /  / /__    * 
*   ___/ ___/ /   / /__/ /__/ ___/    * 
*       SYMBIOSIS MULTITASKING        * 
*       BASED OPERATING SYSTEM        * 
======================================= 
                D O O M 
    (DOOM 3D First-person shooter) 
--------------------------------------- 
  Author: zDoom team,NYYRIKKI,Prodatron 
 Version: 1.0 
    Date: 04.10.2021 
Requires: SymbOS 2.1 
  Memory: 192K (or more) 
--------------------------------------- 
DOOM for SymbOS is a Doom-like 3D 
First-person shooter, one of the few 
or only implementations for the 
supported SymbOS platforms. It is 
running in a window within the GUI, so 
you can even start and play Doom 
multiple times, which wasn't even 
possible back in the early 90ies on a 
32bit system. Running on a 4MHz system 
it's not the fastest game, but some 
optimizations are hopefully possible 
for the future. Doom for SymbOS is a 
port of the original Doom83/zDoom, 
which was developed for the 
TI-83(+)/84+ calculators back in the 
2000ies. 
--------------------------------------- 
This archive contains the following 
files: 
....................................... 
doom.exe       Executable 
doom.hlp       Help 
sources\       Source codes 
Doom-CPC.DSK 
               disk image (CPC or PCW) 
Doom-FAT.DSK 
               disk image (MSX or EP) 
--------------------------------------- 
For additional information please visit 
         http://www.symbos.org 
======================================= 
