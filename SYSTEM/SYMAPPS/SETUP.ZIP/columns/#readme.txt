======================================= 
*     ___       ____  _    ___  ___   * 
*    /__  /__/ / / / /_\  /  / /__    * 
*   ___/ ___/ /   / /__/ /__/ ___/    * 
*       SYMBIOSIS MULTITASKING        * 
*       BASED OPERATING SYSTEM        * 
======================================= 
             C O L U M N S 
             (Puzzle game) 
--------------------------------------- 
  Author: EdoZ/SymbiosiS 
 Version: 1.0 
    Date: 03.06.2015 
Requires: SymbOS 2.1 
  Memory: 192K (or more) 
--------------------------------------- 
This is a very accurate clone of the 
classic puzzle game "Columns". This 
game was developed with Quigs for 
SymbOS. The original was created by 
SEGA. This port is not perfect but it 
shows what can be done with Quigs. 
--------------------------------------- 
This archive contains the following 
files: 
....................................... 
columns.exe    Executable 
columns0.gsh   additional file(s) 
columns1.gsh  
columns2.gsh  
columns3.gsh  
columns4.gsh  
columns5.gsh  
columns6.gsh  
columns7.gsh  
columns8.gsh  
columns9.gsh  
columnsa.gsh  
columnsb.gsh  
columnsc.gsh  
columnsd.gsh  
Columns-CPC.DSK 
               disk image (CPC or PCW) 
Columns-FAT.DSK 
               disk image (MSX or EP) 
--------------------------------------- 
For additional information please visit 
         http://www.symbos.org 
======================================= 
